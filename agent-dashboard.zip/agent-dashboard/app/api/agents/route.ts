import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'

const DEFAULT_AGENTS = [
  {
    id:          'gmail-agent',
    name:        'Gmail Agent',
    type:        'gmail',
    description: 'Sleduje doručenú poštu, upozorňuje na neodpovedané emaily',
    isActive:    true,
  },
  {
    id:          'news-agent',
    name:        'AI News Agent',
    type:        'news',
    description: 'Zbiera novinky od OpenAI, Anthropic, Google, Meta a ďalších',
    isActive:    true,
  },
]

export async function GET() {
  // Ensure default agents exist
  for (const agent of DEFAULT_AGENTS) {
    await prisma.agent.upsert({
      where:  { id: agent.id },
      update: {},
      create: agent,
    }).catch(() => {})
  }

  const agents = await prisma.agent.findMany({
    include: {
      logs: {
        orderBy: { createdAt: 'desc' },
        take: 5,
      },
    },
    orderBy: { createdAt: 'asc' },
  })

  return NextResponse.json({ agents })
}

export async function POST(req: Request) {
  const body = await req.json()
  const agent = await prisma.agent.create({
    data: {
      name:        body.name,
      type:        body.type || 'custom',
      description: body.description || '',
      isActive:    true,
    },
  })
  return NextResponse.json({ agent })
}
