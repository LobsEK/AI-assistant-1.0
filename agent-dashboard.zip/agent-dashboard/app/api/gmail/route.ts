import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '../auth/[...nextauth]/route'
import { google } from 'googleapis'
import { prisma } from '@/lib/prisma'

async function getGmailClient(accessToken: string) {
  const auth = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET
  )
  auth.setCredentials({ access_token: accessToken })
  return google.gmail({ version: 'v1', auth })
}

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.accessToken) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 })
  }

  try {
    const gmail = await getGmailClient(session.accessToken)

    // Fetch unread emails from last 7 days
    const listRes = await gmail.users.messages.list({
      userId: 'me',
      q: 'in:inbox newer_than:7d',
      maxResults: 30,
    })

    const messages = listRes.data.messages || []

    const emails = await Promise.all(
      messages.slice(0, 20).map(async (msg) => {
        const detail = await gmail.users.messages.get({
          userId: 'me',
          id: msg.id!,
          format: 'metadata',
          metadataHeaders: ['From', 'Subject', 'Date'],
        })

        const headers = detail.data.payload?.headers || []
        const get = (name: string) =>
          headers.find(h => h.name === name)?.value || ''

        const from = get('From')
        const nameMatch = from.match(/^"?([^"<]+)"?\s*</)
        const emailMatch = from.match(/<(.+)>/)

        return {
          id: msg.id,
          from_name:  nameMatch?.[1]?.trim() || from,
          from_email: emailMatch?.[1] || from,
          subject:    get('Subject'),
          date:       get('Date'),
          snippet:    detail.data.snippet || '',
          threadId:   detail.data.threadId,
          labelIds:   detail.data.labelIds || [],
        }
      })
    )

    // Log successful sync
    await prisma.agentLog.create({
      data: {
        agentId: 'gmail-agent',
        status:  'success',
        message: `Synced ${emails.length} emails`,
      },
    }).catch(() => {})

    await prisma.agent.updateMany({
      where: { type: 'gmail' },
      data:  { lastSync: new Date() },
    }).catch(() => {})

    return NextResponse.json({ emails, count: emails.length })
  } catch (error: any) {
    console.error('Gmail API error:', error)

    await prisma.agentLog.create({
      data: {
        agentId: 'gmail-agent',
        status:  'error',
        message: error.message,
      },
    }).catch(() => {})

    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
